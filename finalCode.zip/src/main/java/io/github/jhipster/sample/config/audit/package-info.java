/**
 * Audit specific code.
 */
package io.github.jhipster.sample.config.audit;
