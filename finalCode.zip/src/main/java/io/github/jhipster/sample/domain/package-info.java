/**
 * JPA domain objects.
 */
package io.github.jhipster.sample.domain;
