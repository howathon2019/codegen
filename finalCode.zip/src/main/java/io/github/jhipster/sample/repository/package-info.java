/**
 * Spring Data JPA repositories.
 */
package io.github.jhipster.sample.repository;
