/**
 * Data Transfer Objects.
 */
package io.github.jhipster.sample.service.dto;
