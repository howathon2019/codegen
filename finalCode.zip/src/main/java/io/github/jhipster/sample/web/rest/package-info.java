/**
 * Spring MVC REST controllers.
 */
package io.github.jhipster.sample.web.rest;
