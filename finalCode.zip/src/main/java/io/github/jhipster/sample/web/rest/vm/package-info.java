/**
 * View Models used by Spring MVC REST controllers.
 */
package io.github.jhipster.sample.web.rest.vm;
